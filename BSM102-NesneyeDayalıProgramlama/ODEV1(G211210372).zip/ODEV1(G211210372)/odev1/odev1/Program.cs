﻿/*************************************************************************
 **                     SAKARYA ÜNİVERSİTESİ
 **           BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
 **               BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
 **               NESNEYE DAYALI PROGRAMLAMA DERSİ
 **                     2021-2022 BAHAR DÖNEMİ
 **
 **                    ÖDEV NUMARASI: 1
 **                    ÖĞRENCİ ADI: ENES BUĞRA
 **                    ÖĞRENCİ SOYADI: TURĞUT
 **                    ÖĞRENCİ NUMARASI:G211210372
 **                    DERSİN ALINDIĞI GRUP:A
*************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev1
{
    static class Parola
    {
        private static int buyukharfsayisi=0;
        private static int kucukharfsayisi=0;
        private static int rakamsayisi=0;
        private static int sembolsayisi=0;
        private static int puan = 0;

        public static int Buyukharf(string parola) //alinan parola stringini char dizisine cevirir
        {
            char[] karakter = parola.ToCharArray();

            foreach (var buyukharf in karakter) //char dizisindeki elamanlarin kontrolu yapilir
            {
                if (Char.IsUpper(buyukharf)) //bulunan buyuk harf varsa puan ekler ve sayisini arttirir
                {
                    buyukharfsayisi++;
                    puan += 10;
                }
            }
            if (buyukharfsayisi>2)      //bulunan harf sayiyi 2 den fazlaysa puandan fazla olan harf kadar puan cikartilir
                puan -= (buyukharfsayisi-2) * 10;

            return buyukharfsayisi;
        }
        public static int Kucukharf(string parola)
        {
            char[] karakter = parola.ToCharArray();

            foreach (var kucukharf in karakter)
            {
                if (Char.IsLower(kucukharf))
                {
                    kucukharfsayisi++;
                    puan += 10;
                }
            }
            if (kucukharfsayisi > 2)
                puan -= (kucukharfsayisi - 2) * 10;
            return kucukharfsayisi;
        }
        public static int Rakam(string parola)
        {
            char[] karakter = parola.ToCharArray();

            foreach (var rakam in karakter)
            {
                if (Char.IsDigit(rakam))
                {
                    rakamsayisi++;
                    puan += 10;
                }
            }
            if (rakamsayisi > 2)
                puan -= (rakamsayisi - 2) * 10;
            return rakamsayisi;

        }
        public static int Sembol(string parola)
        {
            char[] karakter = parola.ToCharArray();

            foreach (var sembol in karakter)
            {
                if (!Char.IsLetterOrDigit(sembol))
                {
                    sembolsayisi++;
                    puan += 10;
                }
            }
            return sembolsayisi;
        }

        public static int Puan()  //toplanan puanlari mainde gormek icin static puan metodu
        {
            return puan;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            int toplamkaraktersayisi;
            int buyuksayi, kucuksayi, rakamsayi, sembolsayi;
            bool kontrol_space=false;
            string parola;


            while (true)    //bosluk karakteri icermeyene kadar parola istenir 
            {
                Console.WriteLine("Parola Giriniz");
                parola = Console.ReadLine();

                kontrol_space=parola.Contains(" "); //girilen parolada bosluk degeri olup olmadigi kontrol edilir

                if (kontrol_space)
                    Console.WriteLine("SIFRE BOSLUK ICEREMEZ");
                else
                    break;
            }


            buyuksayi  = Parola.Buyukharf(parola);
            kucuksayi  = Parola.Kucukharf(parola);
            rakamsayi  = Parola.Rakam(parola);
            sembolsayi = Parola.Sembol(parola);
            toplamkaraktersayisi = buyuksayi+kucuksayi+rakamsayi+sembolsayi; //static metodlardan gelen degerler degiskenlere aktarilip toplandi

            int puan = Parola.Puan();

            if (toplamkaraktersayisi == 9)  //karakter sayisi 9a esitse extra puan eklenir
                puan += 10;

      
            if (toplamkaraktersayisi >= 9) //toplam karakter sayisi 9ve 9 dan buyukse ve herhangi karakterin sayisi 0a esit degilse
            {
                if (buyuksayi != 0 && kucuksayi != 0 && rakamsayi != 0 && sembolsayi != 0)
                {
                    if (puan < 70)
                    {
                        Console.WriteLine("GENEL PUAN 70DEN KUCUK SIFRE VERILEMEZ");
                        Console.WriteLine("TOPLAM PUAN: " + puan);
                    }
                    else if (puan >= 70 && puan < 90)
                    {
                        Console.WriteLine("SIFRE KABUL EDILIR");
                        Console.WriteLine("TOPLAM PUAN: " + puan);
                    }
                    else if (puan >= 90 && puan <= 100)
                    {
                        Console.WriteLine("SIFRE KABUL EDILIR VE GUCLU");
                        Console.WriteLine("TOPLAM PUAN: " + puan);
                    }
                }
                else
                {
                    Console.WriteLine("HERHANGI BIR KARAKTER SAYISI 0 OLDUGU ICIN SIFRE KABUL EDILEMEZ");
                }
            }
            else //toplam karakter sayisi 9dan kucukse
            {
                Console.WriteLine("KARAKTER SAYISI 9 DAN AZ OLDUGU ICIN SIFRE KABUL EDILEMEZ");
            }
            Console.WriteLine("BUYUK HARF SAYISI: " + buyuksayi);
            Console.WriteLine("KUCUK HARF SAYISI: " + kucuksayi);
            Console.WriteLine("RAKAM SAYISI: "      + rakamsayi);
            Console.WriteLine("SEMBOL SAYISI: "     + sembolsayi);
           

            Console.ReadKey();
        }
    }
}
