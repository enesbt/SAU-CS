﻿/************************************************************
 **                  SAKARYA ÜNİVERSİTESİ
 **          BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
 **              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
 **              NESNEYE DAYALI PROGRAMLAMA DERSİ
 **                  2021-2022 BAHAR DÖNEMİ
 **                  ÖDEV NUMARASI:2
 **                  ÖĞRENCİ ADI:ENES BUĞRA TURĞUT
 **                  ÖĞRENCİ NUMARASI:G211210372
 **                  DERSİN ALINDIĞI GRUP:A
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ODEV_2
{
    class Form1:Form
    {
        //form elemanlarinin tanitilmasi
        private TextBox txtsayi;
        private Label lblyazi;
        private Button btnhesapla;
        public Form1()
        {
            Width = 800;
            Height = 600;
            Text = "Fonksiyon Hesabı";
            FormElemanlari();
        }
        private void FormElemanlari() //form elemanlarinin forma eklenmesi ve ozelliklerinin verilmesi
        {
            //form elemanlari olusturuldu forma eklendi.
            txtsayi = new TextBox();
            txtsayi.SetBounds(350, 120, 100, 80);

            lblyazi = new Label();
            
            lblyazi.Text = "";
            lblyazi.SetBounds(350, 180, 300, 40);
            lblyazi.BackColor = System.Drawing.Color.Gray;
            lblyazi.TextAlign = (System.Drawing.ContentAlignment)HorizontalAlignment.Center;


            btnhesapla = new Button();
            btnhesapla.SetBounds(350, 240, 120, 40);
            btnhesapla.Text = "HESAPLA";

            btnhesapla.MouseClick += Btnhesapla_MouseClick; //form elemanlarina event eklendi
            txtsayi.KeyPress += Txtsayi_KeyPress;

            Controls.Add(txtsayi);
            Controls.Add(lblyazi);
            Controls.Add(btnhesapla);

        }

        private void Txtsayi_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = char.IsLetter(e.KeyChar);  //textbox alanina harf girilmesi engellendi
        }

        private string Tutarhesapla(string tutar)
        {
            string para = "", lira = "", kurus = ""; //tl ve kurusu ayirmak icin degisken tanimlamasi

            string lira_bir = "", lira_on = "", lira_yuz = "", lira_bin = "", lira_onbin = ""; //basamakların string olarak yazilmasi icin
            string kurus_bir = "", kurus_on = ""; 
            int lira_onbinler = 0, lira_binler =0, lira_yuzler = 0, lira_onlar = 0, lira_birler = 0; //lira icin basamaklarin bulunmasi
            int kurus_onlar = 0, kurus_birler = 0; //kurus icin basamaklarin bulunmasi 
            int lira_int = 0, kurus_int = 0; //string olarak alinan tl ve kurusun inte cevrildikten sonra tutulmasi icin

            para = txtsayi.Text.Replace('.', ','); //textboxtan alinan degerin noktanin virgule cevrilerek para degiskenine aktarilması
            
            if (para.IndexOf(',') != -1) //eger virgul varsa kurus ve tl olarak ayirmak icin kontrol ifadesi 
            {
                lira = para.Substring(0, para.IndexOf(','));   //virgule kadar olan kismin liraya aktarilmasi
                kurus = para.Substring(para.IndexOf(',') + 1); //virgulden sonraki kismin kurusa aktarilmasi
                lira_int = Convert.ToInt32(lira);
                kurus_int = Convert.ToInt32(kurus);
            }
            else //virgul yoksa tum deger zaten tl dir
            {
                lira = para.Substring(0);
                lira_int = Convert.ToInt32(lira);
            }
            //basamaklardaki degerlerin belirlenmesi lira ve kurus icin ayri
            lira_onbinler = lira_int / 10000;
            lira_binler = (lira_int - (lira_onbinler * 10000)) / 1000;
            lira_yuzler = (lira_int - ((lira_onbinler * 10000) + (lira_binler * 1000))) / 100;
            lira_onlar = (lira_int - ((lira_onbinler * 10000) + (lira_binler * 1000) + (lira_yuzler * 100))) / 10;
            lira_birler = lira_int % 10;

            kurus_onlar = kurus_int / 10;
            kurus_birler = kurus_int % 10;
            
            if (lira.Length  < 6 && kurus.Length<=2) //lira kisminin 6 basamaktan kucuk ve kurus kisminin 2 basamaktan az olmasi kontrolu
            {

                if (lira_binler==0)
                {
                    switch (lira_onbinler)  //hesaplanan degerlere göre kontrol edilip string ifadelerin yazilmasi
                    {
                        case 1: lira_onbin = "ONBİN"; break;
                        case 2: lira_onbin = "YİRMİBİN"; break;
                        case 3: lira_onbin = "OTUZBİN"; break;
                        case 4: lira_onbin = "KIRKBİN"; break;
                        case 5: lira_onbin = "ELLİBİN"; break;
                        case 6: lira_onbin = "ALTMIŞBİN"; break;
                        case 7: lira_onbin = "YETMİŞBİN"; break;
                        case 8: lira_onbin = "SEKSENBİN"; break;
                        case 9: lira_onbin = "DOKSANBİN"; break;
                        default:
                            break;
                    }
                }
                
                if (lira_binler!=0)
                {
                    switch (lira_onbinler) 
                    {
                        case 1: lira_onbin = "ON"; break;
                        case 2: lira_onbin = "YİRMİ"; break;
                        case 3: lira_onbin = "OTUZ"; break;
                        case 4: lira_onbin = "KIRK"; break;
                        case 5: lira_onbin = "ELLİ"; break;
                        case 6: lira_onbin = "ALTMIŞ"; break;
                        case 7: lira_onbin = "YETMİŞ"; break;
                        case 8: lira_onbin = "SEKSEN"; break;
                        case 9: lira_onbin = "DOKSAN"; break;
                        default:
                            break;
                    }
                    if (lira_binler == 1 && lira_onbinler != 0) //on bir bin sorununu cozmek icin bir stringi eklendi
                        lira_onbin += "BİR";
                }
              
                switch (lira_binler)
                {
                    case 1: lira_bin = "BİN"; break;
                    case 2: lira_bin = "İKİBİN"; break;
                    case 3: lira_bin = "ÜÇBİN"; break;
                    case 4: lira_bin = "DÖRTBİN"; break;
                    case 5: lira_bin = "BEŞBİN"; break;
                    case 6: lira_bin = "ALTIBİN"; break;
                    case 7: lira_bin = "YEDİBİN"; break;
                    case 8: lira_bin = "SEKİZBİN"; break;
                    case 9: lira_bin = "DOKUZBİN"; break;
                    default:
                        break;
                }
                                     
                switch (lira_yuzler)
                {
                    case 1: lira_yuz = "YÜZ"; break;
                    case 2: lira_yuz = "İKİYÜZ"; break;
                    case 3: lira_yuz = "ÜÇYÜZ"; break;
                    case 4: lira_yuz = "DÖRTYÜZ"; break;
                    case 5: lira_yuz = "BEŞYÜZ"; break;
                    case 6: lira_yuz = "ALTIYÜZ"; break;
                    case 7: lira_yuz = "YEDİYÜZ"; break;
                    case 8: lira_yuz = "SEKİZYÜZ"; break;
                    case 9: lira_yuz = "DOKUZYÜZ"; break;
                    default:
                        break;
                }
                switch (lira_onlar)
                {
                    case 1: lira_on = "ON"; break;
                    case 2: lira_on = "YİRMİ"; break;
                    case 3: lira_on = "OTUZ"; break;
                    case 4: lira_on = "KIRK"; break;
                    case 5: lira_on = "ELLİ"; break;
                    case 6: lira_on = "ALTMIŞ"; break;
                    case 7: lira_on = "YETMİŞ"; break;
                    case 8: lira_on = "SEKSEN"; break;
                    case 9: lira_on = "DOKSAN"; break;
                    default:
                        break;
                }
                switch (lira_birler)
                {
                    case 1: lira_bir = "BİR"; break;
                    case 2: lira_bir = "İKİ"; break;
                    case 3: lira_bir = "ÜÇ"; break;
                    case 4: lira_bir = "DÖRT"; break;
                    case 5: lira_bir = "BEŞ"; break;
                    case 6: lira_bir = "ALTI"; break;
                    case 7: lira_bir = "YEDİ"; break;
                    case 8: lira_bir = "SEKİZ"; break;
                    case 9: lira_bir = "DOKUZ"; break;
                    default:
                        break;
                }

                switch (kurus_onlar)
                {
                    case 1: kurus_on = "ON"; break;
                    case 2: kurus_on = "YİRMİ"; break;
                    case 3: kurus_on = "OTUZ"; break;
                    case 4: kurus_on = "KIRK"; break;
                    case 5: kurus_on = "ELLİ"; break;
                    case 6: kurus_on = "ALTMIŞ"; break;
                    case 7: kurus_on = "YETMİŞ"; break;
                    case 8: kurus_on = "SEKSEN"; break;
                    case 9: kurus_on = "DOKSAN"; break;
                    default:
                        break;
                }
                switch (kurus_birler)
                {
                    case 1: kurus_bir = "BİR"; break;
                    case 2: kurus_bir = "İKİ"; break;
                    case 3: kurus_bir = "ÜÇ"; break;
                    case 4: kurus_bir = "DÖRT"; break;
                    case 5: kurus_bir = "BEŞ"; break;
                    case 6: kurus_bir = "ALTI"; break;
                    case 7: kurus_bir = "YEDİ"; break;
                    case 8: kurus_bir = "SEKİZ"; break;
                    case 9: kurus_bir = "DOKUZ"; break;
                    default:
                        break;
                }
            }
            else   //basamak kontrolu
            {
                if(lira.Length>=6)
                    MessageBox.Show("6BASAMAK VE ÜZERİ GİRİS YAPILAMAZ");
                if(kurus.Length>2)
                    MessageBox.Show("KURUS 2DEN FAZLA BASAMAKLI OLAMAZ");

                txtsayi.Text = "";
                lblyazi.Text = "";
            }
            //fonsiyonun string deger dondurup butonun click olayında kullanilmasi icin
            return lblyazi.Text = lira_onbin  + lira_bin + lira_yuz + lira_on + lira_bir + " TL " + kurus_on + kurus_bir + " KURUS";

        }
        private void Btnhesapla_MouseClick(object sender, MouseEventArgs e)
        {
            Tutarhesapla(txtsayi.Text);
        }
        
    }

}
