﻿/*************************************************************************
 **                     SAKARYA ÜNİVERSİTESİ
 **           BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
 **               BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
 **               NESNEYE DAYALI PROGRAMLAMA DERSİ
 **                     2021-2022 BAHAR DÖNEMİ
 **
 **                          Proje Odevi
 **                    ÖĞRENCİ ADI: ENES BUĞRA
 **                    ÖĞRENCİ SOYADI: TURĞUT
 **                    ÖĞRENCİ NUMARASI:G211210372
 **                    DERSİN ALINDIĞI GRUP:A
*************************************************************************/
using System;
using System.IO;
using System.Windows.Forms;

namespace ProjeOdevi
{
    public partial class Form1 : Form
    {
        //sınıfların nesnesi oluşturuldu
        Musteri musteri = new Musteri();
        Magaza magaza = new Magaza();
        DepoUrun depoUrun = new DepoUrun();
        RafUrun rafUrun = new RafUrun();

        //tedarikciler oluşturuldu
        Tedarik tedarikci1 = new Tedarik(1234,"LCW");
        Tedarik tedarikci2 = new Tedarik(2334,"KOTON");
        Tedarik tedarikci3 = new Tedarik(6546,"DEFACTO");
        Tedarik tedarikci = new Tedarik();

        //ürünler oluşturuldu
        Urun urun1 = new Urun("erkek","gomlek",150,40);
        Urun urun2 = new Urun("erkek","tshirt",100,50);
        Urun urun3 = new Urun("erkek","ceket",300,20);
        Urun urun4 = new Urun("kadın","gomlek",200,60);
        Urun urun5 = new Urun("kadın","tshirt",150,68);
        Urun urun6 = new Urun("kadın","ceket",420,77);
        Urun urun7 = new Urun("cocuk","gomlek",80,90);
        Urun urun8 = new Urun("cocuk","tshirt",70,89);
        Urun urun9 = new Urun("cocuk","ceket",100,99);
    
        public Form1()
        {
            //kullanılacak dosyaların oluşturulması 
            InitializeComponent();
            magaza.StokDosyasıOlustur();
            magaza.SatisDosyasıOlustur();
            magaza.SiparisDosyasıOlustur();
            magaza.GiderDosya();
            tedarikci.TedarikDosyasıOlustur();
            tedarikci.TedarikUrunDosyasıOlustur();          
            musteri.MusteriDosyasıOlustur();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            //listview elemanlarına sutun eklenmesi
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.CheckBoxes = true;
            listView1.Columns.Add("Tc", 165);
            listView1.Columns.Add("Ad", 110);
            listView1.Columns.Add("Soyad", 110);
            listView1.Columns.Add("Cinsiyet",110);
            listView1.Columns.Add("Giyim",110);
            listView1.Columns.Add("Adet", 40);
            listView1.Columns.Add("Fiyat", 80);

            listView2.View = View.Details;
            listView2.GridLines = true;
            listView2.FullRowSelect = true;
            listView2.CheckBoxes = true;
            listView2.Columns.Add("Tedarikci", 140);
            listView2.Columns.Add("Cinsiyet", 140);
            listView2.Columns.Add("Giyim",140);
            listView2.Columns.Add("Adet",90);
            listView2.Columns.Add("Fiyat", 85);

            listView3.View = View.Details;
            listView3.GridLines = true;
            listView3.FullRowSelect = true;
            listView3.Columns.Add("Cinsiyet", 140);
            listView3.Columns.Add("Giyim", 140);
            listView3.Columns.Add("Stok", 90);
            listView3.Columns.Add("Fiyat", 45);

            listView4.View = View.Details;
            listView4.GridLines = true;
            listView4.FullRowSelect = true;
            listView4.Columns.Add("Cinsiyet", 140);
            listView4.Columns.Add("Giyim", 140);
            listView4.Columns.Add("Stok", 90);
            listView4.Columns.Add("Fiyat", 45);


            for (int i = 0; i < 101; i++) //adet seçimi için sayılar eklendi
            {
                comboBox3.Items.Add(i);
                comboBox6.Items.Add(i);
                comboBox10.Items.Add(i);
                comboBox12.Items.Add(i);
    
            }
            //dosyaların içeriğinin boş olup olmamasına göre ilk kayıt gerçekleştirilecek
            //önceden kayıt varsa ilk kayıt yapmaya gerek kalmayacak
            bool kontrol = magaza.StokDosyasıBosMuKontrol();
            bool kontrol2 = tedarikci.TedarikDosyasıBosMuKontrol();
            bool kontrol3 = tedarikci.TedarikUrunDosyasıBosMuKontrol();
            bool kontrol4 = magaza.GiderDosyasıBosMuKontrol();

            if (kontrol==true) //oluşturulan ürün nesnelerinin stok dosyasına kayıt edilmesi
            {
                urun1.StokKaydet();
                urun2.StokKaydet();
                urun3.StokKaydet();
                urun4.StokKaydet();
                urun5.StokKaydet();
                urun6.StokKaydet();
                urun7.StokKaydet();
                urun8.StokKaydet();
                urun9.StokKaydet();
            }
            if (kontrol2 == true) //tedarikci nesnelerinin kayıt edilmesi
            {
                tedarikci1.TedarikciKaydet();
                tedarikci2.TedarikciKaydet();
                tedarikci3.TedarikciKaydet();
            }
            if (kontrol3==true) //her tedarikci nesnesine yeni ürün eklenmesi
            {
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "erkek", "gomlek", 100);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "erkek", "tshirt", 70);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "erkek", "ceket", 240);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "kadın", "gomlek", 180);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "kadın", "tshirt", 110);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "kadın", "ceket", 340);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "cocuk", "gomlek", 60);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "cocuk", "tshirt", 45);
                tedarikci1.UrunEkle(tedarikci1.FirmaIsmı, "cocuk", "ceket", 80);

                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "erkek", "gomlek", 95);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "erkek", "tshirt", 72);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "erkek", "ceket", 235);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "kadın", "gomlek", 178);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "kadın", "tshirt", 105);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "kadın", "ceket", 349);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "cocuk", "gomlek", 65);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "cocuk", "tshirt", 50);
                tedarikci2.UrunEkle(tedarikci2.FirmaIsmı, "cocuk", "ceket", 79);


                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "erkek", "gomlek", 102);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "erkek", "tshirt", 75);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "erkek", "ceket", 255);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "kadın", "gomlek", 196);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "kadın", "tshirt", 140);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "kadın", "ceket", 395);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "cocuk", "gomlek", 74);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "cocuk", "tshirt", 66);
                tedarikci3.UrunEkle(tedarikci3.FirmaIsmı, "cocuk", "ceket", 91);

            }
            if (kontrol4==true) //magaza giderlerinin dosyaya yazılması
            {
                magaza.GiderYazDosya();
            }

            //kullanıcı ekranında cinsiyet gösterilmesi için itemler eklendi
            //erkek cocuk ve kadın giyim olduğu için sabit olarak eklendi.
            string[] cinsiyet = { "erkek", "kadın", "cocuk" };
            comboBox1.Items.AddRange(cinsiyet);           
            comboBox4.Items.AddRange(cinsiyet);
            comboBox8.Items.AddRange(cinsiyet);
            comboBox11.Items.AddRange(cinsiyet);
            comboBox14.Items.AddRange(cinsiyet);

            //tedarikciler lislelenmesi icin combobox lara eklendi.
            tedarikci.TedarikciListele(comboBox7);
            tedarikci.TedarikciListele(comboBox13);
        }
 
        private void button1_Click(object sender, EventArgs e)//Satış Oluştur Butonu
        {          
            //seçilen cinsiyet , giyim ,adet ten sonra müşteri bilgileri alınıp kaydedilir.
            //boş bilgi olması halinde seçim yapmadınız hatası verir.
            if (comboBox1.SelectedIndex==-1 || comboBox2.SelectedIndex==-1 ||
                comboBox3.SelectedIndex==-1 || textBox1.Text=="" || textBox2.Text==""
                || textBox3.Text=="")
            {
                MessageBox.Show("Seçim Yapmadınız");
            }
            else
            {
                if (textBox1.Text.Length < 11 || textBox1.Text.Length > 11) //müşteri tc kontrolü
                {
                    MessageBox.Show("tc 11 haneli olmalıdır");
                }
                else
                {
                    bool kontrol;
                    kontrol = musteri.MusteriKontrol(textBox1, textBox2, textBox3);//müşteri tc kontrol varsa true dondurur
                    //seçilen değerlerin değişkenlere aktarılması
                    int adetRaf = Convert.ToInt32(comboBox3.SelectedItem);
                    musteri.Tc = (ulong)Convert.ToInt64(textBox1.Text);
                    musteri.Ad = textBox2.Text;
                    musteri.Soyad = textBox3.Text;

                    string rafCinsiyet = comboBox1.SelectedItem.ToString();
                    string rafGiyim = comboBox2.SelectedItem.ToString();
                    int rafFiyat = rafUrun.RafFiyatGoster(comboBox1, comboBox2);
                    int rafStok = rafUrun.RafStokGoster(comboBox1, comboBox2);

                    if (adetRaf <= rafStok)//seçilen adet ve stok kontrolü
                    {
                        //satış dosyasına satış kaydedilir,müşteri kaydedilir,stok güncellenir.
                        new Musteri(musteri.Ad, musteri.Soyad, musteri.Tc);
                        musteri.SatısKaydet(musteri, rafCinsiyet, rafGiyim, adetRaf, adetRaf * rafFiyat);
                        if (kontrol == false)//aynı tc den musteri dosyasında kayıt olmaması için
                        {
                            musteri.MusteriKaydet();
                        }

                        rafUrun.StokGuncelle(rafCinsiyet, rafGiyim, rafFiyat, adetRaf);
                        TempYaz();
                        MessageBox.Show("Satış Oluşturuldu");
                    }
                    else
                    {
                        MessageBox.Show("Seçtiğiniz Adet Stok Sayısından Fazla Olamaz");
                    }
                    comboBox1.Text = ""; comboBox2.Text = ""; comboBox3.Text = "";
                    label12.Text = ""; label31.Text = ""; textBox1.Text = "";
                    textBox2.Text = ""; textBox3.Text = "";
                    textBox2.Enabled = true; textBox3.Enabled = true;

                }             
            }
           
        }
        private void TempYaz()//temp dosyasının adının stok dosyasına çevrilmesi
        {
            File.Delete(@"c:\projedosya2\stok.txt");
            System.IO.FileInfo fi = new System.IO.FileInfo(@"c:\projedosya2\temp.txt");
            fi.MoveTo(@"c:\projedosya2\stok.txt");
        }
        private void TempYaz2()//temp dosyasının adının siparis dosyasına çevrilmesi
        {
            File.Delete(@"c:\projedosya2\siparis.txt");
            System.IO.FileInfo fi = new System.IO.FileInfo(@"c:\projedosya2\temp2.txt");
            fi.MoveTo(@"c:\projedosya2\siparis.txt");
        }
        private void TempYaz3()//temp dosyasının adının satis dosyasına çevrilmesi
        {
            File.Delete(@"c:\projedosya2\satıs.txt");
            System.IO.FileInfo fi = new System.IO.FileInfo(@"c:\projedosya2\temp2.txt");
            fi.MoveTo(@"c:\projedosya2\satıs.txt");
        }

        private void button2_Click(object sender, EventArgs e)//fiyat görüntüle
        {
            //seçilen raf ürünün fiyat hesapla butonuna basıldığında gösterilmesi
            //seçilen adete göre fiyat verir!!
            if (comboBox3.SelectedIndex==-1 || comboBox1.SelectedIndex ==-1
                || comboBox2.SelectedIndex ==-1
                )
            {
                MessageBox.Show("Hesap İçin Ürün Ve Adet Seçiniz");
            }
            else
            {
                int adetRaf = Convert.ToInt32(comboBox3.SelectedItem);
                int rafFiyat = rafUrun.RafFiyatGoster(comboBox1, comboBox2);
                label12.Text = (adetRaf * rafFiyat).ToString()+"TL";
            }
        }

        private void button4_Click(object sender, EventArgs e)//depodan rafa aktar butonu
        {
            //rafa aktarılacak ürünün seçilmesi ve kaç adet olduğu seçilmesi
            //aktarılan ürün depodan stoğu düşer raftaki stoğu artar.
            if (comboBox4.SelectedIndex == -1 || comboBox6.SelectedIndex == -1 ||
                comboBox5.SelectedIndex == -1 )
            {
                MessageBox.Show("boş alanları doldurunuz");
            }
            else
            {
                int adetDepo = Convert.ToInt32(comboBox6.SelectedItem);
                string depoCinsiyet = comboBox4.SelectedItem.ToString();
                string depoGiyim = comboBox5.SelectedItem.ToString();
                int depoFiyat = depoUrun.DepoFiyatGoster(comboBox4, comboBox5);
                int depoStok = depoUrun.DepoStokGoster(comboBox4, comboBox5);

                if (adetDepo <= depoStok)
                {
                    depoUrun.StokGuncelle(depoCinsiyet, depoGiyim, depoFiyat, adetDepo);
                    TempYaz();
                    depoUrun.DepodanRafaAktar(depoCinsiyet, depoGiyim, depoFiyat, adetDepo);
                    TempYaz();
                    MessageBox.Show("Depodan Rafa Ürün Aktarımı Bşaarılı");
                }
                else
                {
                    MessageBox.Show("seçtiğiniz adet stok sayısından fazla olamaz");
                }
                comboBox4.Text = ""; comboBox5.Text = ""; comboBox6.Text = "";
                label29.Text = ""; label32.Text = "";
              
            }
      
        }

        private void button5_Click(object sender, EventArgs e)//fiyat goruntüle
        {
            //seçilen depodaki urunun depodaki fiyatını gösterir
            //fiyatı seçilen adete göre gösterir!!
            if (comboBox4.SelectedIndex == -1 || comboBox5.SelectedIndex == -1
               || comboBox6.SelectedIndex == -1
               )
            {
                MessageBox.Show("Hesap İçin Ürün Ve Adet Seçiniz");
            }
            else
            {
                int adetDepo = Convert.ToInt32(comboBox6.SelectedItem);
                int depoFiyat = depoUrun.DepoFiyatGoster(comboBox4, comboBox5);
                label29.Text = (adetDepo * depoFiyat).ToString()+"TL";
            }
        }

        private void button6_Click(object sender, EventArgs e)//raf stok goruntule
        {
            //seçilen ürünün raftaki stoğunu gösterir
            if (comboBox1.SelectedIndex == -1
               || comboBox2.SelectedIndex == -1
               )
            {
                MessageBox.Show("Stok İçin Ürün  Seçiniz");
            }
            else
            {
                int rafStok = rafUrun.RafStokGoster(comboBox1, comboBox2);
                label31.Text =rafStok+"ADET";
            }
        }

        private void button7_Click(object sender, EventArgs e)//depo stok goruntuleme
        {
            //seçilen ürünün depodaki stoğunu gösterir
            if (comboBox4.SelectedIndex == -1
               || comboBox5.SelectedIndex== -1
               )
            {
                MessageBox.Show("Stok İçin Ürün  Seçiniz");
            }
            else
            {
                int depoStok = depoUrun.DepoStokGoster(comboBox4, comboBox5);
                label32.Text = depoStok + "ADET";
            }
        }

        private void button3_Click(object sender, EventArgs e)//tedarik siparis ver
        {
            //seçilen üründen adet seçilerek sipariş verilir
            //sipariş edilen ürün adeti depodaki stoğa eklenir
            //sipariş edilen ürün ve tedarikçisi siparişe kaydedilir.
            if (comboBox7.SelectedIndex == -1 || comboBox8.SelectedIndex == -1 ||
                comboBox9.SelectedIndex == -1 || comboBox10.SelectedIndex==-1)
            {
                MessageBox.Show("Boş alanları doldurunuz");
            }
            else
            {
                if (urun1.UrunKontrol(comboBox8,comboBox9)==true)//tedarikciden siparis verilecek ürünün mağazada mevcut olup olmadığı kontrol edilir.
                {
                    //tedarikciden alınan ürün depo stoğuna eklendiği icin öncelikle depoda kaydı olması gerek
                    //bu nedenle depoda kayıtlı olmayan ürün siparis verilemez.
                    int adet = Convert.ToInt32(comboBox10.SelectedItem);
                    string tedarikcii = comboBox7.SelectedItem.ToString();
                    string cinsiyet = comboBox8.SelectedItem.ToString();
                    string giyim = comboBox9.SelectedItem.ToString();
                    int fiyat = tedarikci.UrunFiyatGoster(comboBox7, comboBox8, comboBox9);

                    //siparis kayıt edilir
                    tedarikci1.Siparis(tedarikcii, cinsiyet, giyim, adet, adet * fiyat);
                    //siparis edilen ürün depo stoğuna eklenir
                    depoUrun.StokGuncelle(cinsiyet, giyim, adet);
                    TempYaz();
                    MessageBox.Show("Sipariş Oluşturuldu");

                    label19.Text = "";
                    comboBox7.Text = "";
                    comboBox8.Text = "";
                    comboBox9.Text = "";
                    comboBox10.Text = "";
                }
                else
                {
                    MessageBox.Show("Ürün Mağazada Kayıtlı Değil Yeni Ürün Kaydı Yapınız");
                    label19.Text = "";
                    comboBox7.Text = "";
                    comboBox8.Text = "";
                    comboBox9.Text = "";
                    comboBox10.Text = "";
                }               
            }   
        }
        private void button8_Click(object sender, EventArgs e)//tedarik ürün fiyat gör
        {
            //tedarikçiden seçilen ürünün fiyatı gösterilir
            //fiyat seçilen adete göre değişir !!
            if (comboBox7.SelectedIndex == -1 || comboBox8.SelectedIndex == -1
             || comboBox9.SelectedIndex ==-1 || comboBox10.SelectedIndex== -1
             )
            {
                MessageBox.Show("Hesap İçin Ürün Ve Adet Seçiniz");
            }
            else
            {
                int adetTedarik = Convert.ToInt32(comboBox10.SelectedItem);
                int tedarikFiyat = tedarikci.UrunFiyatGoster(comboBox7, comboBox8, comboBox9);
                label19.Text = (adetTedarik * tedarikFiyat).ToString() + "TL";
            }

        }

        private void button9_Click(object sender, EventArgs e)//satılan ürünleri gör
        {
            //satılan ürünlerin kime satıldığı kaç adet satıldığını dosyadan okuyarak gösterilir.
            listView1.Items.Clear();
            magaza.SatısGoster(listView1);          
        }

        private void button10_Click(object sender, EventArgs e)//satış sayısını gösterir
        {
            if (listView1.Items.Count>0)
            {
                int kayitSayisi = listView1.Items.Count;
                label33.Text = kayitSayisi.ToString();
            }
            else
            {
                MessageBox.Show("ürünleri gösterin");
            }
        }

        private void button11_Click(object sender, EventArgs e)//sipariş edilen ürünleri göster
        {
            //sipariş edilen ürünleri dosyadan okuyarak gösterir
            listView2.Items.Clear();
            magaza.SiparisGoster(listView2);
        }

        private void button12_Click(object sender, EventArgs e) //sipariş sayısını gösterir
        {
            if (listView2.Items.Count > 0)
            {
                int kayitSayisi = listView2.Items.Count;
                label34.Text = kayitSayisi.ToString();
            }
            else
            {
                MessageBox.Show("ürünleri gösterin");
            }
        }

        private void button13_Click(object sender, EventArgs e)//gelir göster
        {
            //satılan ürünlerin fiyatlarını toplayıp gelire ekler
            label20.Text = magaza.GelirGoster().ToString()+" "+"TL";
        }

        private void button14_Click(object sender, EventArgs e)//gider göster
        {
            //sipariş edilen ürünlerin fiyatlarını hesaplayıp gidere ekler
            //gidere magaza giderleri sabit olarak eklenir.
            int siparisGider = magaza.GiderGoster();
            int magazaGider = magaza.MagazaGiderHesapla();
            int toplam = siparisGider + magazaGider;
            label21.Text = toplam.ToString()+" "+"TL";
        }

        private void button15_Click(object sender, EventArgs e)//depo ürünleri göster
        {
            listView3.Items.Clear();
            depoUrun.DepoUrunListele(listView3);
        }

        private void button16_Click(object sender, EventArgs e)//raf ürünleri göster
        {
            listView4.Items.Clear();
            rafUrun.RafUrunListele(listView4);
        }

        private void button17_Click(object sender, EventArgs e)//siparis iptal
        {
            //iptal icin seçilen ürünün bilgileri alınıp dosyadan güncellenir
            int secilenSayisi = listView2.CheckedItems.Count;

            foreach (ListViewItem secili in listView2.CheckedItems)//sipariş iptal için seçilen siparişler
            {
                //iptal için seçilen sipariş bilgilerinin alınması
                string firmaIsmi = secili.SubItems[0].Text.ToString();
                string cinsiyet = secili.SubItems[1].Text.ToString();
                string giyim = secili.SubItems[2].Text.ToString();
                int adet = Convert.ToInt32(secili.SubItems[3].Text);
                int fiyat = Convert.ToInt32(secili.SubItems[4].Text);

                int depostok = depoUrun.DepoStokGoster(cinsiyet, giyim);
                //depoya aktarılan sipariş depodan rafa aktarıldığında sipariş iptal olamaz
                //bu kontrol yapılmadığında stok eksiye düşer
                //depodaki ürünün stoğu rafa aktarılmadığında her zaman sipariş verilen adede eşit veya daha büyük olur
                if (depostok<adet)//depodaki stok siparişi iptal edilecek adetten az ise 
                {
                    MessageBox.Show("Sipariş Verildikten Sonra Rafa Aktarılan Ürün İptal Edilemez");
                }
                else
                {
                    secili.Remove();
                    //iptal edilen sipariş sipariş dosyasından silinir
                    tedarikci.Siparisİptal(firmaIsmi, cinsiyet, giyim, adet, fiyat);
                    TempYaz2();
                    //depodaki stok iptal edildiği için güncellenir
                    depoUrun.StokGuncelleİptal(cinsiyet, giyim, adet);
                    TempYaz();
                    MessageBox.Show(secilenSayisi.ToString() + " Adet Sipariş İptal Edildi!!");
                }               
            }         
        }

        private void button18_Click(object sender, EventArgs e)//satış iptal
        {
            int secilenSayisi = listView1.CheckedItems.Count;
            //satılan ürünler listesinde seçilen ürünler
            foreach (ListViewItem secili in listView1.CheckedItems)
            {
                secili.Remove();

                ulong tc =Convert.ToUInt64(secili.SubItems[0].Text.ToString());
                string ad = secili.SubItems[1].Text.ToString();
                string soyad = secili.SubItems[2].Text.ToString();
                string cinsiyet = secili.SubItems[3].Text.ToString();
                string giyim = secili.SubItems[4].Text.ToString();
                int adet = Convert.ToInt32(secili.SubItems[5].Text);
                int fiyat = Convert.ToInt32(secili.SubItems[6].Text);

                musteri.Satisİptal(tc,ad,soyad,cinsiyet,giyim,adet,fiyat);
                TempYaz3();
                //satış iptal olduğunda raf stoğu güncellenir
                rafUrun.StokGuncelleİptal(cinsiyet,giyim,adet);
                TempYaz();
            }
            MessageBox.Show(secilenSayisi.ToString() + " Adet Satış İptal Edildi!!");
        }

        private void button19_Click(object sender, EventArgs e)//ürün ekle
        {
            //yeni eklenecek ürünün zaten mağazada olup olmadığını kontrol etme
            bool kontrol;
            kontrol = urun1.UrunKontrol(comboBox11, textBox4);
          
            if (comboBox11.SelectedIndex==-1||comboBox12.SelectedIndex==-1||
                textBox4.Text==""||textBox5.Text=="")
            {
                MessageBox.Show("Boş Alanları Doldurunuz");
            }
            else
            {
                if (kontrol == true)//ürün mevcutsa
                {
                    MessageBox.Show("Ürün zaten mevcut!!!");
                    comboBox11.Text = "";
                    comboBox12.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                }
                else//ürün mevcut değilse
                {
                    string cinsiyet = comboBox11.Text;
                    string giyim = textBox4.Text.ToLower();
                    int stok = Convert.ToInt32(comboBox12.Text);
                    int fiyat = Convert.ToInt32(textBox5.Text);

                    //yeni ürün nesnesi oluşturulup dosyaya kayıt edilir.
                    new Urun(cinsiyet, giyim, fiyat, stok).StokKaydet();
                   
                    comboBox11.Text = "";
                    comboBox12.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    MessageBox.Show("ürün eklendi!");
                }              
            }
           
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)//seçilen cinsiyete göre ürün gösterilmesi raf
        {
            comboBox2.Items.Clear();
            comboBox2.Text = "";
            urun1.UrunGoster(comboBox2,comboBox1);
        }

        private void comboBox4_SelectedValueChanged(object sender, EventArgs e)//seçilen cinsiyete göre ürün gösterilmesi depo
        {
            comboBox5.Items.Clear();
            comboBox5.Text = "";
            urun1.UrunGoster(comboBox5, comboBox4);
        }


        private void textBox1_TextChanged(object sender, EventArgs e)//Müşteri tc kontrol
        {
            bool kontrol = musteri.MusteriKontrol(textBox1,textBox2,textBox3);
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)//tedarikçi urunleri göster
        {
            comboBox9.Items.Clear();
            comboBox9.Text = "";
            tedarikci.TedarikUrunGoster(comboBox9, comboBox7, comboBox8);
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)//tedarikçi urunleri göster
        {
            comboBox9.Items.Clear();
            comboBox9.Text = "";
            tedarikci.TedarikUrunGoster(comboBox9, comboBox7, comboBox8);
        }

        private void button21_Click(object sender, EventArgs e)//tedarikçi ekle
        {
            //tedarikcinin mevcut olup olamdığını kontrol değişkenine atanır
            bool kontrol;
            kontrol= tedarikci.TedarikciKontrol(textBox8, textBox9);

            if (textBox8.Text==""||textBox9.Text=="")
            {
                MessageBox.Show("Boş Alanları Doldurunuz");
            }
            else
            {
                if (kontrol==true)
                {
                    MessageBox.Show("Firma zaten mevcut!!!");
                    textBox8.Text = "";
                    textBox9.Text = "";
                }
                else
                {
                    int firmano =Convert.ToInt32(textBox8.Text);
                    string firmaİsmi = textBox9.Text.ToUpper();
                    //yeni tedarikci nesnesi oluşturulup dosyaya kaydedilir
                    new Tedarik(firmano, firmaİsmi).TedarikciKaydet();

                    textBox8.Text = "";
                    textBox9.Text = "";
                    MessageBox.Show("Yeni Tedarikçi Eklendi");
                    comboBox7.Items.Clear();
                    comboBox13.Items.Clear();
                    tedarikci.TedarikciListele(comboBox7);
                    tedarikci.TedarikciListele(comboBox13);

                }
            }
        }

        private void button20_Click(object sender, EventArgs e)//tedarikci urun ekle
        {
            //tedarikcilerin ürünleri arasında yeni eklencek ürünün mevcut olup olmadığını kontrol etme
            bool kontrol;
            kontrol = tedarikci.TedarikUrunKontrol(comboBox13, comboBox14, textBox6);

            if (comboBox13.SelectedIndex==-1||comboBox14.SelectedIndex==-1||
                textBox6.Text==""||textBox7.Text=="")
            {
                MessageBox.Show("Boş Alanları Doldurun!!");
            }
            else
            {

                if (kontrol==true)
                {
                    MessageBox.Show("Ürün Zaten Mevcut");
                    comboBox13.Text = "";
                    comboBox14.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                }
                else
                {
                    string firma = comboBox13.Text;
                    string cinsiyet = comboBox14.Text;
                    string giyim = textBox6.Text.ToLower();
                    int fiyat=Convert.ToInt32(textBox7.Text);

                    tedarikci.UrunEkle(firma, cinsiyet, giyim, fiyat);
                    comboBox13.Text = "";
                    comboBox14.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    MessageBox.Show("Ürün Eklendi");
                }
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)//tc rakam girişi
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        //sadece rakam ve yazı girisi icin kodlar eklendi
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                && !char.IsSeparator(e.KeyChar);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                && !char.IsSeparator(e.KeyChar);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                && !char.IsSeparator(e.KeyChar);
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                 && !char.IsSeparator(e.KeyChar);
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                 && !char.IsSeparator(e.KeyChar);
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
