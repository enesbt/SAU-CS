﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjeOdevi
{
    class Musteri:Magaza
    {
        //müşteri değişkenlerinin tanımlanması
        private string ad;
        private string soyad;
        private ulong tc;

        public string Ad
        {
            get { return ad;}
            set { ad = value; }
        }
        public string Soyad
        {
            get { return soyad; }
            set { soyad = value; }
        }
        public ulong Tc
        {
            get { return tc; }
            set { tc = value; }
        }

        public Musteri() //parametresiz kurucu
        {
            ad = "";
            soyad = "";
            tc = 0;
        }
        public Musteri(string ad,string soyad,ulong tc) //parametreli kurucu
        {
            this.ad = ad;
            this.soyad = soyad;
            this.tc = tc;
        }
        public void MusteriDosyasıOlustur() //müşteri bilgilerini kaydetmek için müşteri dosyasının oluşturulması
        {
            string dosyadi = "musteri.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        }

        public void MusteriKaydet() //müşteri bilgilerinin müşteri dosyasına yazılması
        {
            StreamWriter musteri = new StreamWriter(@"c:\projedosya2\musteri.txt", true);
            musteri.WriteLine(this.tc + " " + this.ad + " " + this.soyad);
            musteri.Close();
        }
        public void SatısKaydet(Musteri m1, string cinsiyet, string giyim, int adet, int fiyat) //satılan ürünün satış dosyasına kaydedilmesi
        {
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;
            StreamWriter satıs = new StreamWriter(@"c:\projedosya2\satıs.txt", true);
            satıs.WriteLine(m1.Tc + " " + m1.Ad + " " + m1.Soyad + " " + cinsiyet + " " + giyim + " " + adet + " adet" + " " + fiyat + " tl");
            satıs.Close();
        }
        public void Satisİptal(ulong tc,string ad,string soyad, string cinsiyet, string giyim, int adet, int fiyat)
        {
            //satışı iptal edilen ürün dahil edilmeden diğer ürünler temp dosyasına kayıt edilir.
            StringBuilder newFile = new StringBuilder();
            string guncel = "";

            string[] lines = File.ReadAllLines(@"c:\projedosya2\satıs.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');

                if (parts[0] == tc.ToString()&&parts[1]==ad&&parts[2]==soyad 
                    && parts[3] == cinsiyet && parts[4] == giyim && parts[5] == adet.ToString() &&
                    parts[7] == fiyat.ToString())
                {

                }
                else
                {
                    guncel = parts[0] + " " + parts[1] + " " + parts[2] + " " + parts[3] + " " + parts[4] + " " + parts[5] + " " + "adet"+
                        " "+parts[7]+" "+"tl";
                    newFile.Append(guncel + " \r\n");
                }

            }
            File.WriteAllText(@"c:\projedosya2\temp2.txt", newFile.ToString());
        }
        public bool MusteriDosyasıBosMuKontrol() // müşteri dosyasının boş olup olmadığını kontrol etme
        {
            var info = new FileInfo(@"c:\projedosya2\musteri.txt");
            bool kontrol = false;
            if ((!info.Exists) || info.Length == 0)
            {
                kontrol = true;
            }
            return kontrol;
        }

        public bool MusteriKontrol(TextBox txtbx,TextBox txtbx2,TextBox txtbx3)//satış için müşteri tc girildiğinde kayıtlarda olup olmadığı kontrol edilir
        {
            bool kontrol = false;
            StreamReader oku = new StreamReader(@"c:\projedosya2\musteri.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                //girilen müşteri tc si kayıtlarda varsa isim ve soyismi eklenir ve erişime kapanır
                if (txtbx.Text == urundizi[0])
                {
                    kontrol = true;
                    txtbx2.Text = urundizi[1];
                    txtbx3.Text = urundizi[2];
                    txtbx2.Enabled = false;
                    txtbx3.Enabled = false;
                }
            }
            oku.Close();
            return kontrol;
        }
    }
}
