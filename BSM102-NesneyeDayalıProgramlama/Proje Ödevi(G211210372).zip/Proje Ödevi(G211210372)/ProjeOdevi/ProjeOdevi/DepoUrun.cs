﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;


namespace ProjeOdevi
{
    class DepoUrun : Urun
    {
        //depourun değişkeni tanımlanması
        private int depoStok;

        public int DepoStok
        {
            get { return depoStok; }
            set { depoStok = value; }
        }
        public DepoUrun()
        {
            depoStok = 0;
        } //parametresiz kurucu
        public DepoUrun(string cinsiyet, string giyim, int fiyat, int depoStok) //parametreli kurucu
        {
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;
            this.depoStok = depoStok;
        }

        public void DepoUrunListele(ListView listview) //depodaki ürünlerin listviewde görüntülenmesi
        {
            //stok dosyası satır satır okunarak kaydı depo olanların alınıp listview e aktarılması
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;          
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0]=="depo")
                {
                    string cinsiyet = urundizi[1];
                    string giyim = urundizi[2];
                    string stok = urundizi[3];
                    string fiyat = urundizi[5];
                    string[] bilgiler = { cinsiyet, giyim, stok, fiyat };
                    listview.Items.Add(new ListViewItem(bilgiler));
                }              
            }
            oku.Close();
        }
        public int DepoStokGoster(ComboBox cmb1, ComboBox cmb2) //seçilen ürünün stok sayısını öğrenme
        {
            //comboboxta seçilen ürünün dosyadaki ürünle karşılaştırıp stok sayısını elde ettik
            //cmb1 cinsiyet , cmb2 giyim seçim ürünü
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0] == "depo") //depo türü olduğu
                {
                    if (cmb1.SelectedItem.ToString() == urundizi[1] && cmb2.SelectedItem.ToString() == urundizi[2])
                    {
                        depoStok = Convert.ToInt32(urundizi[3]);
                    }
                }
               
            }
            oku.Close();
            return depoStok;
        }
        public int DepoStokGoster(string cinsiyet, string giyim) //iptal için stok görme
        {          
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0] == "depo") //depo türü olduğu
                {
                    if (cinsiyet == urundizi[1] && giyim == urundizi[2])
                    {
                        depoStok = Convert.ToInt32(urundizi[3]);
                    }
                }
            }
            oku.Close();
            return depoStok;
        }

        public int DepoFiyatGoster(ComboBox cmb1, ComboBox cmb2) //seçilen ürünün fiyatını öğrenme
        {
            //comboboxta seçilen ürünün fiyatını dosyadan eşliştirip öğrenme
            //cmb1 cinsiyet , cmb2 giyim seçim ürünü
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0]=="depo")
                {
                    if (cmb1.SelectedItem.ToString() == urundizi[1] && cmb2.SelectedItem.ToString() == urundizi[2])
                    {
                        fiyat = Convert.ToInt32(urundizi[5]);
                    }
                }             
            }
            oku.Close();
            return fiyat;
        }
        public void StokGuncelle(string cinsiyet, string giyim,int fiyat,int adet)
        {
            //depo ürünün stoğunun güncellenmesi
            //stok dosyası satır satır okunup türü depo olanlar ve parametre olarak verilen değerler dosyadaki değerlere eşitse
            //stok güncellenir bu fonksiyon depodan rafa aktarmada depodan aktarılan ürünün stoğunun düşmesi için kullanıldı.  
            int stokk;          
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);
                
                if (parts[0] == "depo" && parts[1]==cinsiyet && parts[2]==giyim)
                {                    
                    stokk = Convert.ToInt32(parts[3]) - adet;
                    DepoStok = stokk;
                    string yaz = "depo" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + fiyat + " " + "tl";
                    lines[i] = yaz;
                }              
            }
            //temp dosyasına değişen değer ve diğer veriler yazılır.
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }
        public void DepodanRafaAktar(string cinsiyet, string giyim, int fiyat, int adet)
        {
            //bu fonksiyon depodan rafa aktarmada depodan rafa aktarılan ürünün raftaki stoğunun artması için kullanıldı.
            int stokk;
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);

                if (parts[0] == "raf" && parts[1] == cinsiyet && parts[2] == giyim)
                {
                    stokk = Convert.ToInt32(parts[3]) + adet;

                    string yaz = "raf" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + fiyat + " " + "tl";
                    lines[i] = yaz;
                }
            }
            //temp dosyasına değişen değer ve diğer veriler yazılır.
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }
        public void StokGuncelle(string cinsiyet, string giyim, int adet)//tedarikciden siparis edilen ürünün depodaki stoğunun artması için
        {
            //depo ürünün stoğunun güncellenmesi sipariş için
            int stokk;
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);

                if (parts[0] == "depo" && parts[1] == cinsiyet && parts[2] == giyim)
                {
                    stokk = Convert.ToInt32(parts[3]) + adet;
                    DepoStok = stokk;
                    string yaz = "depo" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + parts[5] + " " + "tl";
                    lines[i] = yaz;
                }
            }
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }
        public void StokGuncelleİptal(string cinsiyet, string giyim, int adet)//iptal edilen sipariş için stok güncellemesi
        {
            //iptal edilen ürünün stoğu alınan kadar azaltılır
            int stokk;
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);

                if (parts[0] == "depo" && parts[1] == cinsiyet && parts[2] == giyim)
                {
                    stokk = Convert.ToInt32(parts[3]) - adet;
                    DepoStok = stokk;
                    string yaz = "depo" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + parts[5] + " " + "tl";
                    lines[i] = yaz;
                }
            }
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }

    }
}
