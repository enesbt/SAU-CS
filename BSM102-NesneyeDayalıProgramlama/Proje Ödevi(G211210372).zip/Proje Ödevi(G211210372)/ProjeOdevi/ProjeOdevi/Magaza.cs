﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjeOdevi
{
    class Magaza
    {
        //ana sınıf magazanın değişkenlerinin tanımlanması
        private readonly int elemanGideri; 
        private readonly int elektrikGideri;
        private readonly int suGideri;
        private readonly int ısıtmaGideri;
        private int toplamMagazaGider;
        private int gelir;
        private int gider;

        //kalıtım alacak sınıfların kullanabilmesi için protected kullanıldı
        protected string giyim;
        protected string cinsiyet;
        protected int fiyat;
        public int Gelir
        {
            get { return gelir; }
            set { gelir = value; }
        }
        public int Gider
        {
            get { return gider; }
            set { gider = value; }
        }


        public Magaza() //magaza giderlerine ilk deger ataması
        {         
            elemanGideri = 2400;
            elektrikGideri = 1250;
            suGideri = 820;
            ısıtmaGideri = 1800;
            toplamMagazaGider = 0;
            gelir = 0;
            gider = 0;
        }
        public void GiderDosya() //gider dosyası oluşturuldu
        {
            string dosyadi = "gider.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        }
        public int MagazaGiderHesapla() //magazanın kendi giderlerinin toplanıp hesaplanması
        {
            toplamMagazaGider = elemanGideri + elektrikGideri + suGideri+ ısıtmaGideri;
            return toplamMagazaGider;
        }
        public void GiderYazDosya() //giderlerin dosyaya kaydedilmesi
        {
            StreamWriter gider = new StreamWriter(@"c:\projedosya2\gider.txt", true);
            gider.WriteLine("eleman gideri"+" "+elemanGideri);
            gider.WriteLine("elektrik gideri" + " " + elektrikGideri);
            gider.WriteLine("su gideri" + " " + suGideri);
            gider.WriteLine("ısıtma gideri" + " " + ısıtmaGideri);
            gider.Close();
        }
        public bool GiderDosyasıBosMuKontrol()
        {
            var info = new FileInfo(@"c:\projedosya2\gider.txt");
            bool kontrol = false;
            if ((!info.Exists) || info.Length == 0)
            {
                kontrol = true;
            }
            return kontrol;
        } // dosya içerisi boş mu kontrol edilmesi
        public void StokDosyasıOlustur()
        {
            string dosyadi = "stok.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        } //ürünler için stok dosyasının oluşturulması
        public bool StokDosyasıBosMuKontrol()
        {
            var info = new FileInfo(@"c:\projedosya2\stok.txt");
            bool kontrol = false;
            if ((!info.Exists) || info.Length == 0)
            {
                kontrol = true;
            }
            return kontrol;
        } //dosya içerisi boş mu kontrol edilmesi
        public void SatisDosyasıOlustur()
        {
            string dosyadi = "satıs.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        }  //satılan ürünlerin kaydedilmesi için satış dosyası oluşturulması
        public void SiparisDosyasıOlustur()
        {
            string dosyadi = "siparis.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        } //sipariş edilen ürünlerin kaydedilmesi için sipariş dosyasının oluşturulması
        public int GelirGoster() //satılan ürünler dosyasındaki toplam fiyatları toplayıp gelire eklenmesi.
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\satıs.txt");
            string satıs;
            string[] satısDizi;
            int toplam = 0;
            while (!oku.EndOfStream)
            {
                satıs = oku.ReadLine();
                satısDizi = satıs.Split(' ');
                int fiyat = Convert.ToInt32(satısDizi[7]);
                toplam += fiyat;
                Gelir = toplam;
            }
            oku.Close();
            return Gelir;
        }
        public int GiderGoster() //sipariş edilen ürünlerin fiyatlarının toplanıp gidere eklenemesi
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\siparis.txt");
            string siparis;
            string[] siparisDizi;
            int toplam = 0;
            while (!oku.EndOfStream)
            {
                siparis = oku.ReadLine();
                siparisDizi = siparis.Split(' ');
                int fiyat = Convert.ToInt32(siparisDizi[5]);
                toplam += fiyat;
                Gider = toplam;
            }
            oku.Close();
            return Gider;
        }
        public void SiparisGoster(ListView listview) //sipariş edilen ürünlerin listview de gösterilmesi
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\siparis.txt");
            string siparis;
            string[] siparisDizi;
            while (!oku.EndOfStream)
            {
                siparis = oku.ReadLine();
                siparisDizi = siparis.Split(' ');
                string tedarikci = siparisDizi[0];
                string cinsiyet = siparisDizi[1];
                string giyim = siparisDizi[2];
                string adet = siparisDizi[3];
                string fiyat = siparisDizi[5];
                string[] bilgiler = { tedarikci, cinsiyet, giyim, adet, fiyat };
                listview.Items.Add(new ListViewItem(bilgiler));

            }
            oku.Close();
        }
        public void SatısGoster(ListView listview) //satılan ürünlerin listview de gösterilmesi
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\satıs.txt");
            string satıs;
            string[] satısDizi;
            while (!oku.EndOfStream)
            {
                satıs = oku.ReadLine();
                satısDizi = satıs.Split(' ');
                string tc = satısDizi[0];
                string ad = satısDizi[1];
                string soyad = satısDizi[2];
                string cinsiyet = satısDizi[3];
                string giyim = satısDizi[4];
                string adet = satısDizi[5];
                string fiyat = satısDizi[7];
                string[] bilgiler = { tc, ad, soyad, cinsiyet, giyim, adet, fiyat };
                listview.Items.Add(new ListViewItem(bilgiler));
            }
            oku.Close();
        }
 
    }
}
