﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace ProjeOdevi
{
    class Urun:Magaza
    {
        //magaza sınıfından kalıtım aldığı için giyim,cinsiyet,fiyat değişkeni magaza sınıfından gelir.
        protected int stok;
        public string Giyim
        {
            get { return giyim; }
            set { giyim = value; }
        }
        public string Cinsiyet
        {
            get { return cinsiyet; }
            set { cinsiyet = value;}
        }
        public int Fiyat
        {
            get { return fiyat;}
          
        }
        public int Stok
        {
            get { return stok; }
            set { stok = value; }
        }

        public Urun()
        {
            stok =0;
        } //parametresiz kurucu
        public Urun(string cinsiyet,string giyim,int fiyat,int stok) //parametreli kurucu
        {
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;
            this.stok = stok;
        }     
        public void StokKaydet() //oluşturulan ürün nesnesi dosyaya hem depo hem raf olarak kaydedilir.
        { 
            StreamWriter stok = new StreamWriter(@"c:\projedosya2\stok.txt", true);
            stok.WriteLine("depo" + " " + this.cinsiyet + " " + this.giyim + " " + this.stok + " " + "adet" + " " + this.fiyat + " " + "tl");
            stok.WriteLine("raf" + " " + this.cinsiyet + " " + this.giyim + " " + this.stok + " " + "adet" + " " + this.fiyat + " " + "tl");
            stok.Close();
        }

        public void UrunGoster(ComboBox cmb1,ComboBox cmb2) //ürünlerdeki giyim kategorisinin comboboxta listelenebilmesi için fonksiyon
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream) //dosya sonuna kadar satır satır okur.
            {
                urun = oku.ReadLine(); //her satırını urun değişkeni tutuyor
                urundizi = urun.Split(' '); // urun değişkenini boşluklara göre bölüp diziye çevrildi         
                string giyim = urundizi[2]; //urundizi her satırdaki kelimeleri dizi olarak tutuyor her satırın 2. kelimesi giyim değerini tuttuğu için ona atadık.

                if (cmb2.Text==urundizi[1]) //cinsiyete göre ürünleri gösterir
                {
                    cmb1.Items.Add(giyim);
                }                                                   
            }
            string[] dizi = new string[cmb1.Items.Count]; //giyim ürünleri tekrar ettiği için bunu engellemek için
            cmb1.Items.CopyTo(dizi, 0);                   //comboboxtaki değerleri kopyalayıp özel fonksiyonla tekrar edenleri silip geçici diziye atıyoruz
            var gecicidizi = dizi.Distinct();             // ve geçici dizideki değerleri combobox a tekrar yazdırıyoruz
            cmb1.Items.Clear();
            foreach (string s in gecicidizi)
            {
                cmb1.Items.Add(s);
            }
            oku.Close();
        }

        public bool UrunKontrol(ComboBox cmb1,TextBox txtbx) //yeni ürün eklerken aynı ürünün dosyada mevcut olup olmadığını kontrol eder
        {
            bool kontrol = false;
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
               
                if (cmb1.SelectedItem.ToString() == urundizi[1] && txtbx.Text.ToLower() == urundizi[2])
                {
                    kontrol = true;
                }
                
            }
            oku.Close();
            return kontrol;
        }
        public bool UrunKontrol(ComboBox cmb1, ComboBox cmb2)//yeni ürün eklerken aynı ürünün dosyada mevcut olup olmadığını kontrol eder
        {
            bool kontrol = false;
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');

                if (cmb1.SelectedItem.ToString() == urundizi[1] && cmb2.SelectedItem.ToString() == urundizi[2])
                {
                    kontrol = true;
                }

            }
            oku.Close();
            return kontrol;
        }
    }
}
