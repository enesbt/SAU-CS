﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace ProjeOdevi
{
    class Tedarik:Magaza
    {
        //tedarik sınıfı değişkenleri tanımlanması
        private string firmaIsmi;
        private int firmaNo;


        public string Giyim
        {
            get { return giyim; }
            set { giyim = value; }
        }
        public string Cinsiyet
        {
            get { return cinsiyet; }
            set { cinsiyet = value; }
        }
        public int Fiyat
        {
            get { return fiyat; }
        }
        public string FirmaIsmı
        {
            get { return firmaIsmi; }
            set { firmaIsmi = value;}
        }
        public int FirmaNo
        {
            get { return firmaNo; }
            set { firmaNo = value; }
        }

        public Tedarik()
        {
            firmaIsmi = "";
            firmaNo = 0;
        } //parametresiz kurucu
        public Tedarik(int firmaNo,string firmaIsmı)
        {
            this.firmaNo = firmaNo;
            this.firmaIsmi = firmaIsmı;
        } //parametreli kurucu
        public void TedarikDosyasıOlustur() //tedarikçilerin firma ismi ve firma numarasını tutmak için dosya oluşturulması
        {
            string dosyadi = "tedarik.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        } 
        public void TedarikUrunDosyasıOlustur()//tedarikçilerin ürünlerini tutmak için dosya oluşturulması
        {
            string dosyadi = "tedarikurun.txt";
            string doyayolu = @"c:\projedosya2";
            string hedefyol = Path.Combine(doyayolu, dosyadi);

            if (File.Exists(hedefyol)) { }
            else { File.Create(hedefyol); }
        }
       
        public void TedarikciKaydet() //tedarikçilerin dosyaya kaydedilmesi
        {
            StreamWriter tedarik = new StreamWriter(@"c:\projedosya2\tedarik.txt", true);
            tedarik.WriteLine(this.firmaNo + " " + this.firmaIsmi);
            tedarik.Close();
        }
        public void UrunEkle(string firmaIsmi, string cinsiyet,string giyim,int fiyat) //tedarikçilere ürün eklenmesi
        {
            this.firmaIsmi = firmaIsmi;
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;

            StreamWriter urun = new StreamWriter(@"c:\projedosya2\tedarikurun.txt", true);
            urun.WriteLine(firmaIsmi + " " + cinsiyet + " "+giyim+" " + fiyat + " " + "tl");
            urun.Close();
        }
       
        public void Siparis(string firmaIsmi, string cinsiyet,string giyim, int adet,int fiyat)//magaza siparişinin sipariş dosyasına kaydedilmesi. 
        {
            this.firmaIsmi = firmaIsmi;
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;
            StreamWriter stok = new StreamWriter(@"c:\projedosya2\siparis.txt", true);

            stok.WriteLine(firmaIsmi + " " + cinsiyet+" "+giyim + " " + adet + " " + "adet"+" "+fiyat+" "+"tl");
            stok.Close();
        }
        public void Siparisİptal(string firmaIsmi, string cinsiyet, string giyim, int adet, int fiyat)
        {
            //iptal edilen ürün eklenmeden diğer ürünler temp dosyasına kayıt edilir
            StringBuilder newFile = new StringBuilder();
            string guncel = "";

            string[] lines = File.ReadAllLines(@"c:\projedosya2\siparis.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');

                if (parts[0] == firmaIsmi && parts[1] == cinsiyet && parts[2] == giyim&&parts[3]==adet.ToString()&&
                    parts[5]==fiyat.ToString())
                {

                }
                else
                {
                    guncel = parts[0] + " " + parts[1] + " " + parts[2] + " " + parts[3] + " " + "adet" + " " + parts[5] + " " + "tl";
                    newFile.Append(guncel+" \r\n");
                }
              
            }
            File.WriteAllText(@"c:\projedosya2\temp2.txt", newFile.ToString());
        }
        public int UrunFiyatGoster(ComboBox cmb1, ComboBox cmb2,ComboBox cmb3) //tedarik ürünlerinin fiyatının öğrenilmesi
        {
            //tedarikçiden seçilen ürünün ,  ürün dosyasından bulunup fiyatının öğrenilmesi
            StreamReader oku = new StreamReader(@"c:\projedosya2\tedarikurun.txt");
            string urun;
            string[] urundizi;
           
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                //cmb1 tedarikçi firma ismini tutuyor
                //cmb2 cinsiyet değerini,
                //cmb3 giyim değerini tutuyor
                if (cmb1.SelectedItem.ToString() == urundizi[0] && cmb2.SelectedItem.ToString() == urundizi[1]
                    && cmb3.SelectedItem.ToString()==urundizi[2])
                {
                    fiyat = Convert.ToInt32(urundizi[3]);
                }
                
            }
            oku.Close();
            return fiyat;
        }
        public bool TedarikDosyasıBosMuKontrol()//dosya içerisi boş mu kontrol edilmesi
        {
            var info = new FileInfo(@"c:\projedosya2\tedarik.txt");
            bool kontrol = false;
            if ((!info.Exists) || info.Length == 0)
            {
                kontrol = true;
            }
            return kontrol;
        }
        public bool TedarikUrunDosyasıBosMuKontrol()//dosya içerisi boş mu kontrol edilmesi
        {
            var info = new FileInfo(@"c:\projedosya2\tedarikurun.txt");
            bool kontrol = false;
            if ((!info.Exists) || info.Length == 0)
            {
                kontrol = true;
            }

            return kontrol;
        }

        public void TedarikciListele(ComboBox cmb) //dosyadaki kayıtlı tedarikçilerin magazanın seçim yapabilmesi için combobox ta gösterilmesi
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\tedarik.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                cmb.Items.Add(urundizi[1]);
              
            }
            oku.Close();
        }

        public void TedarikUrunGoster(ComboBox cmb1,ComboBox cmb2,ComboBox cmb3)//tedarikçi ürünlerinin giyim kategorisinin comboboxta listelenebilmesi için fonksiyon
        {
            //Urun goster fonksiyonunda yapılan işlemler yapıldı
            StreamReader oku = new StreamReader(@"c:\projedosya2\tedarikurun.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
             
                string giyim = urundizi[2];

                if (cmb2.Text==urundizi[0]&& cmb3.Text==urundizi[1])
                {
                    cmb1.Items.Add(giyim);
                }
               
            
            }
            string[] dizi = new string[cmb1.Items.Count];
            cmb1.Items.CopyTo(dizi, 0);
            var gecicidizi = dizi.Distinct();
            cmb1.Items.Clear();
            foreach (string s in gecicidizi)
            {
                cmb1.Items.Add(s);
            }

            oku.Close();
        }

        public bool TedarikciKontrol(TextBox txtbx1,TextBox txtbx2)//yeni tedarikci eklenmesi durumunda eklenen tedarikcinin mevcut olup olmadığını kontrol etmek icin
        {
            bool kontrol = false;
            StreamReader oku = new StreamReader(@"c:\projedosya2\tedarik.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                //firma numarası ya da  firma ismi eşleşirse firmanın kayıtlı olduğu bilinir.
                if (txtbx1.Text == urundizi[0] || txtbx2.Text.ToUpper() == urundizi[1])
                {
                    kontrol = true;
                }
            }
            oku.Close();
            return kontrol;

        }
        public bool TedarikUrunKontrol(ComboBox cmb1, ComboBox cmb2, TextBox txtbx1)//tedarikciler icin ürün eklerlen ürünün tedarikcide olup olmadığını kontrol etmek icin
        {
            bool kontrol = false;
            StreamReader oku = new StreamReader(@"c:\projedosya2\tedarikurun.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                //firma ismi ve ürün eşleşirse ürünün mevcut olduğu görülür.
                if (cmb1.Text == urundizi[0] && cmb2.Text== urundizi[1] && txtbx1.Text.ToLower()==urundizi[2])
                {
                    kontrol = true;
                }
            }
            oku.Close();
            return kontrol;
        }
    }
}
