﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;

namespace ProjeOdevi
{
    class RafUrun:Urun
    {
        //rafurun değişkeni tanımlanması
        private int rafStok;

        public int RafStok
        {
            get { return rafStok; }
            set { rafStok = value; }
        }
        public RafUrun() //parametresiz kurucu
        {
            rafStok = 0;
        }
        public RafUrun(string cinsiyet, string giyim, int fiyat, int rafStok)//parametreli kurucu
        {
            this.cinsiyet = cinsiyet;
            this.giyim = giyim;
            this.fiyat = fiyat;
            this.rafStok = rafStok;
        }
        public void StokGuncelle(string cinsiyet, string giyim, int fiyat, int adet)
        {
            //raf üründen satış olduğunda ürünün stoğunun adet kadar düşürülmesi
            int stokk;
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);

                if (parts[0] == "raf" && parts[1] == cinsiyet && parts[2] == giyim)
                {
                    stokk = Convert.ToInt32(parts[3]) - adet;
                    RafStok = stokk;
                    string yaz = "raf" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + fiyat + " " + "tl";
                    lines[i] = yaz;
                }
            }
            //sadece stoğu değişen ürün değişir diğer ürünler aynı şekilde temp dosyasına kaydedilir.
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }
        public void RafUrunListele(ListView listview) //stok dosyasındaki raf ürünlerinin listview de gösterilemesi
        {
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0] == "raf")
                {
                    string cinsiyet = urundizi[1];
                    string giyim = urundizi[2];
                    string stok = urundizi[3];
                    string fiyat = urundizi[5];
                    string[] bilgiler = { cinsiyet, giyim, stok, fiyat };
                    listview.Items.Add(new ListViewItem(bilgiler));
                }
            }
            oku.Close();
        }

        public int RafStokGoster(ComboBox cmb1,ComboBox cmb2)//seçilen ürünün stok sayısını öğrenme
        {
            //comboboxta seçilen ürünün dosyadaki ürünle karşılaştırıp stok sayısını elde ettik
            //cmb1 cinsiyet , cmb2 giyim seçim ürünü
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0]=="raf")
                {
                    if (cmb1.SelectedItem.ToString() == urundizi[1] && cmb2.SelectedItem.ToString() == urundizi[2])
                    {
                        rafStok = Convert.ToInt32(urundizi[3]);
                    }
                }
               
            }
            oku.Close();
            return rafStok;
        }
        public int RafFiyatGoster(ComboBox cmb1, ComboBox cmb2)//seçilen ürünün fiyatını öğrenme
        {
            //comboboxta seçilen ürünün fiyatını dosyadan eşliştirip öğrenme
            //cmb1 cinsiyet , cmb2 giyim seçim ürünü
            StreamReader oku = new StreamReader(@"c:\projedosya2\stok.txt");
            string urun;
            string[] urundizi;
            while (!oku.EndOfStream)
            {
                urun = oku.ReadLine();
                urundizi = urun.Split(' ');
                if (urundizi[0] == "raf")
                {
                    if (cmb1.SelectedItem.ToString() == urundizi[1] && cmb2.SelectedItem.ToString() == urundizi[2])
                    {
                        fiyat = Convert.ToInt32(urundizi[5]);
                    }
                }             
            }
            oku.Close();
            return fiyat;
        }
        public void StokGuncelleİptal(string cinsiyet, string giyim, int adet)//iptal edilen satış için stok güncellemesi
        {
            //satışı olan ürün stoktan azaldığı için iptal edilince stoğunun artması için
            int stokk;
            string[] lines = File.ReadAllLines(@"c:\projedosya2\stok.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(' ');
                stokk = Convert.ToInt32(parts[3]);
                //bölünnen satır indisleri eşleştirilmesi
                if (parts[0] == "raf" && parts[1] == cinsiyet && parts[2] == giyim)
                {
                    stokk = Convert.ToInt32(parts[3]) + adet;
                    RafStok = stokk;
                    string yaz = "raf" + " " + cinsiyet + " " + giyim + " " + stokk + " " + "adet" + " " + fiyat + " " + "tl";
                    lines[i] = yaz;
                }
            }
            File.WriteAllLines(@"c:\projedosya2\temp.txt", lines);
        }

    }
}
