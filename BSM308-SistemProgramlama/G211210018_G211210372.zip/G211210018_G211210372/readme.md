# Proje Ekibi
- Mehmet OK
- Enes Buğra TURĞUT

# Amaç
- Veri dosyasından okunan komutlara göre çıkış dosyasının oluşturulması.
# İçerik
#### komut.c
- yaz() : belirlenen adette çıkış dosyasına belirlenen karakteri yazar.
- sil() : belirlenen adette çıkış dosyasından belirlenen karakteri imlecin kaldığı yerden dosya başına kadar tarayarak siler.
- sonagit() : dosyanın kaldığı yeri dosya sonuna taşır.
#### test.c
- giriş ve çıkış için dosya adları argv olarak alınır.
- giriş dosyası satır satır okunur ve her satırdaki komutlar ve işlenecek veriler alınır.
- ilgili komut çağrılarak gerekli işlem yapılır.
- dur komutu geldiğinde giriş ve çıkış dosyası kapatılır.
- giriş ve çıkış için verilen dosya adı bulunamaz ise default dosyalar çalışır.

# Derleme
- make
# Çalıştırma
- ./bin/test [giris.dat] [cikis.dat]
