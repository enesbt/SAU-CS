#include <stdio.h>
#include <stdlib.h>
#include "fields.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "komut.h"

int main(int argc, char **argv)
{

  IS is;
  int i;
  int fd, sz;

  char *input;
  char *output;

  if(argc == 3){
    input = argv[1];
    output = argv[2]; 
  }
  else{
    printf("Something went wrong: number of mismatched parameters!\n");
    input = "default_giris.dat";
    output = "default_cikis.dat";
  }

  is = new_inputstruct(input);
  fd = open(output, O_RDWR | O_CREAT | O_TRUNC, 0644);

  int adet = 0;
  char *karakter;

  while (get_line(is) >= 0)
  {
    if (strcmp(is->fields[0], "yaz:") == 0)
    {
      for (i = 1; i < is->NF; i++)
      {
        adet = atoi(is->fields[i]);
        karakter = is->fields[++i];
        yaz(fd, karakter, adet);
      }
    }
    else if (strcmp(is->fields[0], "sil:") == 0) // sil komutu
    {
      for (i = 1; i < is->NF; i++)
      {
        adet = atoi(is->fields[i]);
        karakter = is->fields[++i];
        sil(fd, karakter, adet);
      }
    }
    else if (strcmp(is->fields[0], "sonagit:") == 0) // sonagit komutu
    {
      sonagit(fd);
    }
    else if(strcmp(is->fields[0],"dur:")==0) //dur komutu
    {
      jettison_inputstruct(is);
      close(fd);
      exit(0);
    }
    else
    {
      fprintf(stderr, "bad command detected\n");
    }
  }

  jettison_inputstruct(is);
  close(fd);

  return 0;
}
