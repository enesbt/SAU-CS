# Web-Technologies-Project

## Proje Amacı
Kendimi ve şehrimi tanıttığım kişisel web sitesi oluşturmak.

## Projede Kullanılan Teknolojiler
* HTML
* CSS
* Bootstrap
* JavaScript
* PHP

## Proje İçeriği
* Hakkında Sayfası
    * Giriş sayfası kısaca kendimi tanıttığım sayfa.
* Özgeçmiş Sayfası
    * Eğitim bilgilerini içeren cv niteliğinde sayfa.
* Şehrim Sayfası
    * Ankaranın tanıtıldığı sayfa
* Takımımız Sayfası
    * Şehrin takımının tanıtıldığı sayfa.
* İlgi Alanlarım Sayfası
    * API servisinden alınan spor film bilgileri içeren sayfa.
* İletişim Sayfası
    * Kullanıcının bilgilerini girerek görüşlerini belirtebildiği sayfa.
* Login Sayfası
    * Adminin giriş yapabildiği sayfa.
