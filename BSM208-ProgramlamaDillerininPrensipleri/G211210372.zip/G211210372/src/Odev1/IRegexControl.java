package Odev1;

public interface IRegexControl 
{
	public void classNameRegex();
	public void functionsControl();
	public void matchFunctionsFunctionsNames();	
	public void matchSingleLineComments();
	public void matchMultiLineComments();
	public void matchJavaDocComments();	
	public void longFunctionNames();
	public void curlyCount();
	public void yazdir();
}
