package Odev1;
import java.util.*;

public interface IReadJarFile 
{
	public void readFile();	
	
	public Map<String,Integer> curlyCount(List<String> list);
	
}
