/**
 * 
 */
/**
 * @author Enes
 *
 */
module Odev3 {
}