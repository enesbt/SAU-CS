/**
*
* @author Enes Buğra Turğut bugra.turgut@ogr.sakarya.edu.tr
* @since 23.05.2023
* <p>
* 	Taktik arayuzu
* </p>
*/

package Odev3;

public interface Taktik 
{
	public int Savas(int populasyon);
	
}
