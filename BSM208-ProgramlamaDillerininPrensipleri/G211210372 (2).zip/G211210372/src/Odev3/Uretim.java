/**
*
* @author Enes Buğra Turğut bugra.turgut@ogr.sakarya.edu.tr
* @since 23.05.2023
* <p>
* 	Uretim arayuzu
* </p>
*/

package Odev3;

public interface Uretim 
{
	public int Uret(int populasyon);

}
