#ifndef MUTASYON_HPP
#define MUTASYON_HPP
#include "kontrol.hpp"

class Mutasyon
{
    public:
        void mutasyon(Organizma*);
};


#endif