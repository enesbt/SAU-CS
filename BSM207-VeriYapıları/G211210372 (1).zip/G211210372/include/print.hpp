#ifndef PRINT_HPP
#define PRINT_HPP
#include "kontrol.hpp"

class Print
{
    public:
        void yazdir(Organizma*);
};


#endif